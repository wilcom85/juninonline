var c=document.getElementById("circulo");
var cxt=c.getContext("2d");

ext.fillStyle="blue";
ext. beginPath();
ext.arc(60,60,50,0,Math.PI*2,true);
cxt.closePath;
cxt.fill();