
				var c= document.getElementById("welcome");
				var cxt= c.getContext("2d");
				
				cxt.moveTo(10,10);
				cxt.lineTo(10,70);
				cxt.lineTo(15,90);
				cxt.lineTo(20,70);
				cxt.lineTo(20,50);
				cxt.lineTo(20,70);
				cxt.lineTo(25,90);
				cxt.lineTo(30,70);
				cxt.lineTo(30,10);
				
				cxt.moveTo(35,10);
				cxt.lineTo(35,90);
				
				cxt.moveTo(40,10);
				cxt.lineTo(40,90);
				cxt.lineTo(50,90);
				cxt.lineTo(50,85);
				
				cxt.moveTo(65,15);
				cxt.lineTo(65,10);
				cxt.lineTo(55,10);
				cxt.lineTo(55,90);
				cxt.lineTo(65,90);
				cxt.lineTo(65,85);
				
				cxt.moveTo(70,10);
				cxt.lineTo(70,90);
				cxt.lineTo(80,90);
				cxt.lineTo(80,10);
				cxt.lineTo(70,10);
				
				cxt.moveTo(85,90);
				cxt.lineTo(85,10);
				cxt.lineTo(95,50);
				cxt.lineTo(105,10);
				cxt.lineTo(105,90);
				
				cxt.moveTo(115,15);
				cxt.lineTo(120,10);
				cxt.lineTo(120,90);
				
				cxt.stroke();